1. Dir repo jdid f GitHub w upload kolchi (m3a .github)
2. Actions > Build APK > Run workflow
3. Telechargi gaming-h6r-apk mn Artifacts
